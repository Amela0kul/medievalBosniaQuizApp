package com.example.kviz;

public class QuestionAnswer {
    public static String question[]={
            "Ko je bio prvi poznati vladar Bosanske države u srednjem vijeku?",
"Sa kojom titulom je pogubljen posljednji bosanski vladar?",
        "Koji najstariji dosad pronađeni bosanski državni dokument?",
                "Kako se zvao posljednji vladar Srednjovijekovne bosanske države?"
    };

    public static String choices[][]={
        {"Ban Kulin","Tvrtko I","Tvrtko II","Ban Borić"},
        {"Car","Kralj","Ban","Ostalo"},
        {"Statut Kotromanića","Povelja Kulina bana","Humska ploča","Ostalo"},
        {"Stjepan Ostoja","Stjepan Tomašević","Tvrtko II","Ostalo"}
    };

    public static String correctAneswers[]={
            "Ban Borić",
            "Kralj",
            "Povelja Kulina bana",
            "Stjepan Tomašević"

    };
}
